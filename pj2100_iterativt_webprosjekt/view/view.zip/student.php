<p>Hei, jeg er student.php.</p>

<p>Her skal det stå om hvordan det er å være student og hva man kan få ut av det.</p>
			<?php
				if ($filename != '' && $filename != 'utvalg' && $filename != 'kalender') {
					echo '</div>';
    				include 'view/menu.php';
    			}
			?>

			</div>

            <div id="footer">
                Copyright &copy; Gruppe 33 | <a href="kontakt.php">Kontakt</a>
            </div>
        </div>

        <script type="text/javascript" src="view/js/jquery.js"></script>
        <script type="text/javascript" src="view/js/jquery.custombox.js"></script>
        <script type="text/javascript" src="view/js/custombox.js"></script>

    </body>
</html>


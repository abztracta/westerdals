<!DOCTYPE html>
<html>
    <head>
        <link rel="stylesheet" href="<?php echo ROOT_HOST . 'view/css/style.css';?>"/>
        <link rel="stylesheet" href="<?php echo ROOT_HOST . 'view/css/custombox.css';?>"/>
        <meta charset="utf-8" />
        <title>
            Westerdals Student
        </title>
    </head>
    <body>

        <div id="wrapper">
            <div id="login_wrap">
                <div id="login_left">
                    <?php
                        if (isset($_SESSION['uid'])) {
                            echo 'Innlogget som: ' . $_SESSION['firstname'] . " " . $_SESSION['lastname'];
                        }
                    ?>
                </div>

                <div id="login_right">
                    <?php
                        if (isset($_SESSION['uid'])) {
                    ?>
                    <a href="<?php echo ROOT_HOST . 'brukerprofil'?>">Profil</a>
                    &nbsp;|&nbsp;
                    <a href="<?php echo ROOT_HOST . 'logoutEvent';?>">Logg ut </a>

                    <?php
                        } else {
                    ?>

                    <a href="<?php echo ROOT_HOST . 'login';?>">Logg inn</a>
                    &nbsp;|&nbsp;
                    <a href="<?php echo ROOT_HOST . 'registrering';?>">Registrer</a>
                    
                    <?php
                        }
                    ?>
                </div>
            </div>

            <a href="<?php echo ROOT_HOST;?>">
                <div id="header">
                </div>
            </a>

            <div id="content">

            <?php 
                if ($filename != '') {
                    echo '<div id="text_content">';
                }
            ?>
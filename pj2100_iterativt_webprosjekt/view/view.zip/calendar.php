<div id="calendar-wrapper">
	<h1>Kalender</h1>

	<a href="http://vg.no">
		<div class="calendar-event">
		
			<div class="calendar-img">
				<img src="#" alt="" />
					<div class="calendar-date" style="background-color: #fargebæsj">
						<span>Desember</span>24
					</div>
			</div>
		
			<div class="calendar-content">
				<span class="calendar-utvalg" style="color: #fargebæsj">Utvikling</span><br/>
				<span class="calendar-title">Jeg er en tittel da, jeg er kul</span>

				<span class="calendar-place-date">
					Sted, 24. september 1991 03:14
				</span>
			</div>
		</div>
	</a>


	<a href="http://vg.no">
		<div class="calendar-event">
		
			<div class="calendar-img">
				<img src="#" alt="" />
					<div class="calendar-date">
						<span>Desember</span>24
					</div>
			</div>
		
			<div class="calendar-content">
				<span class="calendar-utvalg">Utvikling</span><br/>
				<span class="calendar-title">Jeg er en tittel da, jeg er kul</span>

				<span class="calendar-place-date">
					Sted, 24. september 1991 03:14
				</span>
			</div>
		</div>
	</a>


	<a href="http://vg.no">
		<div class="calendar-event">
		
			<div class="calendar-img">
				<img src="#" alt="" />
					<div class="calendar-date">
						<span>Desember</span>24
					</div>
			</div>
		
			<div class="calendar-content">
				<span class="calendar-utvalg">Utvikling</span><br/>
				<span class="calendar-title">Jeg er en tittel da, jeg er kul</span>

				<span class="calendar-place-date">
					Sted, 24. september 1991 03:14
				</span>
			</div>
		</div>
	</a>
</div>
<div id="menu_wrapper">
	<a href="<?php echo ROOT_HOST . 'utvalg';?>">
		<img src="view/images/menu/utvalg.png" alt="Utvalg" />
		<span>Utvalg</span>
	</a>

	<a href="<?php echo ROOT_HOST . 'kalender';?>">
		<img src="view/images/menu/kalender.png" alt="Kalender" />
		<span>Kalender</span>
	</a>

	<a href="<?php echo ROOT_HOST . 'student';?>">
		<img src="view/images/menu/student.png" alt="Student" />
		<span>Student</span>
	</a>
</div>

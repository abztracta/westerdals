<div id="utvalg_wrapper">
	<h1>Utvalg</h1>
	
	<div class="utvalg_wrapper_small">
		<div class="utvalg_left_wrap">
			<a href="#utvikling" class="small_links btn-custombox"><img src="view/images/studentcommunity/utvikling.jpg" alt=""/><span>Utvikling</span></a>
			<a href="#support" class="small_links btn-custombox"><img src="view/images/studentcommunity/support.jpg" alt="" /><span>Support</span></a>
			<a href="#leder" class="small_links btn-custombox"><img src="view/images/studentcommunity/leder.jpg" alt="" /><span>Leder</span></a>
			<a href="#kvinner" class="small_links btn-custombox"><img src="view/images/studentcommunity/kvinner.jpg" alt="" /><span>Kvinner</span></a>
		</div>
		
		<div class="utvalg_right_wrap">
			<a href="#sosialt" class="large_links btn-custombox"><img src="view/images/studentcommunity/sosialt.jpg" alt="" /><span>Sosialt</span></a>
		</div>
	</div>

	<div class="utvalg_wrapper_small">
		<div class="utvalg_left_wrap">
			<a href="#kroa" class="large_links btn-custombox"><img src="view/images/studentcommunity/kroa.jpg" alt="" /><span>Kroa</span></a>
		</div>

		<div class="utvalg_right_wrap">
			<a href="#spill" class="small_links btn-custombox"><img src="view/images/studentcommunity/spill.jpg" alt="" /><span>Spill</span></a>
			<a href="#musikk" class="small_links btn-custombox"><img src="view/images/studentcommunity/musikk.jpg" alt="" /><span>Musikk</span></a>
			<a href="#film" class="small_links btn-custombox"><img src="view/images/studentcommunity/film.jpg" alt=""/><span>Film</span></a>
			<a href="#kunst" class="small_links btn-custombox"><img src="view/images/studentcommunity/kunst.jpg" alt="" /><span>Kunst</span></a>
		</div>		
	</div>

	<div class="utvalg_wrapper_small">
		<div class="utvalg_middle_wrap">
			<a href="#teater" class="small_links btn-custombox"><img src="view/images/studentcommunity/teater.jpg" alt="" /><span>Teater</span></a>
			<a href="#apple" class="small_links btn-custombox"><img src="view/images/studentcommunity/apple.jpg" alt="" /><span>Apple</span></a>
			<a href="#idrett" class="small_links btn-custombox"><img src="view/images/studentcommunity/idrett.jpg" alt="" /><span>Idrett</span></a>
			<a href="#skrive" class="small_links btn-custombox"><img src="view/images/studentcommunity/skrive.jpg" alt="" /><span>Skrive</span></a>
		</div>
	</div>
</div>

<div id="utvikling" class="custombox">
	<img src="view/test.png" alt"" class="custombox-img" />
	<div class="custombox-text">
		<h3>Test</h3>
		Hei, jeg er utvikling.
	</div>
	<div class="calendar-small-wrapper">

		<h3>Aktiviteter</h3>
		<a href="http://vg.no">
		<div class="calendar-small-event">
		
			<div class="calendar-small-img">
				<img src="#" alt="" />
			</div>
		
			<div class="calendar-small-content">
				<span class="calendar-small-title">Jeg er en tittel da, jeg er kul</span>

				<span class="calendar-small-place-date">
					Sted, 24. september 1991 03:14
				</span>
			</div>
		</div>
		</a>
	</div>
</div>

<div id="support" class="custombox">
	<img src="view/test.png" alt"" class="custombox-img" />
	<div class="custombox-text">
		Hei, jeg er support.
	</div>
</div>

<div id="leder" class="custombox">
	<img src="view/test.png" alt"" class="custombox-img" />
	<div class="custombox-text">
		Hei, jeg er leder.
	</div>
</div>

<div id="kvinner" class="custombox">
	<img src="view/test.png" alt"" class="custombox-img" />
	<div class="custombox-text">
		Hei, jeg er kvinner.
	</div>
</div>

<div id="sosialt" class="custombox">
	<img src="view/test.png" alt"" class="custombox-img" />
	<div class="custombox-text">
		Hei, jeg er sosialt.
	</div>
</div>

<div id="kroa" class="custombox">
	<img src="view/test.png" alt"" class="custombox-img" />
	<div class="custombox-text">
		Hei, jeg er kroa.
	</div>
</div>

<div id="spill" class="custombox">
	<img src="view/test.png" alt"" class="custombox-img" />
	<div class="custombox-text">
		Hei, jeg er spill.
	</div>
</div>

<div id="musikk" class="custombox">
	<img src="view/test.png" alt"" class="custombox-img" />
	<div class="custombox-text">
		Hei, jeg er musikk.
	</div>
</div>

<div id="film" class="custombox">
	<img src="view/test.png" alt"" class="custombox-img" />
	<div class="custombox-text">
		Hei, jeg er film.
	</div>
</div>

<div id="kunst" class="custombox">
	<img src="view/test.png" alt"" class="custombox-img" />
	<div class="custombox-text">
		Hei, jeg er kunst.
	</div>
</div>

<div id="teater" class="custombox">
	<img src="view/test.png" alt"" class="custombox-img" />
	<div class="custombox-text">
		Hei, jeg er teater.
	</div>
</div>

<div id="apple" class="custombox">
	<img src="view/test.png" alt"" class="custombox-img" />
	<div class="custombox-text">
		Hei, jeg er apple.
	</div>
</div>

<div id="idrett" class="custombox">
	<img src="view/test.png" alt"" class="custombox-img" />
	<div class="custombox-text">
		Hei, jeg er idrett.
	</div>
</div>

<div id="skrive" class="custombox">
	<img src="view/test.png" alt"" class="custombox-img" />
	<div class="custombox-text">
		Hei, jeg er skrive.
	</div>
</div>